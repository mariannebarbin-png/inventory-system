<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    {{-- Begin Dashboard Content --}}
                    <h1 class="text-2xl font-bold mb-4">Dashboard</h1>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                        <!-- Total Items -->
                        <div class="p-4 bg-blue-100 rounded">
                            <h2 class="font-bold">Total Items</h2>
                            <p class="text-xl">{{ \App\Models\Item::count() }}</p>
                            @if(auth()->user()->role === 'admin')
                                <a href="{{ route('items.index') }}" class="text-blue-700 underline">Manage Items</a>
                            @endif
                        </div>

                        <!-- Total Transactions -->
                        <div class="p-4 bg-green-100 rounded">
                            <h2 class="font-bold">Total Items</h2>
                            <p class="text-xl">{{ \App\Models\Item::count() }}</p>
                            <a href="{{ route('items.index') }}" class="text-green-700 underline">View Transactions</a>
                        </div>

                        <!-- User Role -->
                        <div class="p-4 bg-yellow-100 rounded">
                            <h2 class="font-bold">Your Role</h2>
                            <p class="text-xl capitalize">{{ auth()->user()->role }}</p>
                        </div>

                    </div>
                    {{-- End Dashboard Content --}}

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
